//! Memory bus (lead-owned): memory map, waitstates, IO dispatch, IRQ regs, timers, DMA.
//! Also owns Ppu and Apu; `sync()` advances every component by the cycles the CPU consumed.
pub mod save;
use crate::apu::Apu;
use crate::ppu::Ppu;
use save::Save;

static BIOS: &[u8] = include_bytes!("../assets/bios.bin");
const PRESCALE: [u32; 4] = [0, 6, 8, 10];
// calibration knobs (checked against nba-hw timer tests)
const VCOUNT_ADJ: u64 = 0;
const VBLANK_DELAY: u32 = 8;
const PF_CAP: u64 = 8;
const PF_MISS_EXTRA: u32 = 0;
const START_DELAY: u32 = 1;
const READ_ADJ: u32 = 2;
const NWAIT: [u32; 4] = [4, 3, 2, 8];

#[derive(Clone, Copy, Default)]
struct Timer { reload: u16, counter: u16, ctrl: u16, acc: u32, on: bool, delay: u32 }
#[derive(Clone, Copy, Default)]
struct Dma { src: u32, dst: u32, left: u32 }

pub struct Bus {
    pub cycles: u64,
    synced: u64,
    pub ppu: Ppu,
    pub apu: Apu,
    pub rom: Vec<u8>,
    pub rom_len: usize,
    pub save: Save,
    /// CPU may set this to the address of the executing instruction; BIOS reads are
    /// protected (return `bios_latch`) when it is >= 0x4000.
    pub fetch_pc: u32,
    /// Value returned for unmapped reads; CPU may update it with the last prefetched opcode.
    pub open_bus: u32,
    bios_latch: u32,
    ewram: Vec<u8>,
    iwram: Vec<u8>,
    io: [u16; 0x200],
    ie: u16, iflag: u16, ime: u16,
    halt: bool,
    postflg: u8,
    waitcnt: u16,
    rom_n: [u32; 3], rom_s: [u32; 3], sram_w: u32, prefetch: bool,
    pub keys: u32,
    key_cond: bool,
    /// set when the PPU reaches line 160 (end of visible frame); cleared by `take_frame`
    frame_done: bool,
    /// PPU position within the frame in cycles (tracked here to model flag delays)
    ppu_pos: u32,
    pub trace_mem: bool,
    pub memlog: Vec<(u32, u32, u32, bool)>,
    timers: [Timer; 4],
    dma: [Dma; 4],
    dma_latch: u32,
    in_dma: bool,
    dma_pending: u8, fifo_mask: u8,
    fifo_buf: [u32; 2],
    pf_next: u32, pf_buf: u32, pf_last: u64,
}

fn ld(b: &[u8], i: usize, sz: u32) -> u32 {
    match sz {
        1 => b[i] as u32,
        2 => u16::from_le_bytes([b[i], b[i + 1]]) as u32,
        _ => u32::from_le_bytes([b[i], b[i + 1], b[i + 2], b[i + 3]]),
    }
}
fn st(b: &mut [u8], i: usize, sz: u32, v: u32) {
    match sz {
        1 => b[i] = v as u8,
        2 => b[i..i + 2].copy_from_slice(&(v as u16).to_le_bytes()),
        _ => b[i..i + 4].copy_from_slice(&v.to_le_bytes()),
    }
}

impl Bus {
    pub fn new() -> Self {
        let mut b = Bus {
            cycles: 0, synced: 0, ppu: Ppu::new(), apu: Apu::new(),
            rom: vec![0; 32 << 20], rom_len: 0, save: Save::new(save::Kind::Sram),
            fetch_pc: 0x0800_0000, open_bus: 0, bios_latch: 0xE129_F000,
            ewram: vec![0; 0x40000], iwram: vec![0; 0x8000], io: [0; 0x200],
            ie: 0, iflag: 0, ime: 0, halt: false, postflg: 0, waitcnt: 0,
            rom_n: [5; 3], rom_s: [3, 5, 9], sram_w: 5, prefetch: false,
            keys: 0, key_cond: false, frame_done: false, ppu_pos: 0, trace_mem: false, memlog: Vec::new(), timers: [Timer::default(); 4], dma: [Dma::default(); 4],
            dma_latch: 0, in_dma: false, dma_pending: 0, fifo_mask: 0, fifo_buf: [0; 2],
            pf_next: 0, pf_buf: 0, pf_last: 0,
        };
        b.set_waitcnt(0);
        b
    }

    /// Reset everything except ROM contents. Detects the save type from the ROM.
    pub fn reset(&mut self) {
        self.cycles = 0; self.synced = 0;
        self.ppu.reset(); self.apu.reset();
        // post-BIOS register state
        self.ppu.write_io(0, 0x80, 0xFFFF); // forced blank until the game sets DISPCNT
        for o in [0x20, 0x26, 0x30, 0x36] { self.ppu.write_io(o, 0x100, 0xFFFF); }
        self.save = Save::detect(&self.rom[..self.rom_len]);
        self.fetch_pc = 0x0800_0000; self.open_bus = 0; self.bios_latch = 0xE129_F000;
        self.ewram.fill(0); self.iwram.fill(0); self.io = [0; 0x200];
        self.ie = 0; self.iflag = 0; self.ime = 0; self.halt = false; self.postflg = 0;
        self.keys = 0; self.key_cond = false; self.frame_done = false; self.ppu_pos = 0;
        self.timers = [Timer::default(); 4]; self.dma = [Dma::default(); 4];
        self.dma_latch = 0; self.in_dma = false; self.dma_pending = 0; self.fifo_mask = 0; self.fifo_buf = [0; 2];
        self.pf_next = 0; self.pf_buf = 0; self.pf_last = 0;
        self.set_waitcnt(0);
    }

    pub fn dbg(&self) -> String { format!("ie={:x} if={:x} ime={:x} halt={} timers={:?} dispcnt={:x} dispstat={:x}", self.ie, self.iflag, self.ime, self.halt, self.timers.iter().map(|t| (t.on, t.counter)).collect::<Vec<_>>(), self.ppu.read_io(0), self.ppu.read_io(4)) }
    pub fn irq_line(&self) -> bool { self.ime & 1 != 0 && self.ie & self.iflag & 0x3FFF != 0 }
    pub fn halted(&self) -> bool { self.halt && self.ie & self.iflag & 0x3FFF == 0 }
    pub fn idle(&mut self, c: u32) { self.cycles += c as u64; }
    pub fn take_frame(&mut self) -> bool { std::mem::take(&mut self.frame_done) }

    /// Re-phase the PPU as if the real BIOS had just finished: the reference emulator enters the ROM
    /// with the PPU 277219 cycles into the frame (line 225, cycle 19). Called once the boot stub reached the ROM.
    pub fn align_ppu(&mut self) {
        self.ppu.reset();
        self.ppu.write_io(0, 0x80, 0xFFFF);
        for o in [0x20, 0x26, 0x30, 0x36] { self.ppu.write_io(o, 0x100, 0xFFFF); }
        let mut left = 0u32;
        self.ppu_pos = left;
        while left > 0 { let d = left.min(200); self.ppu.tick(d); left -= d; }
        self.iflag &= !7;
        self.frame_done = false;
        self.bios_latch = 0xE129_F000; // what the real BIOS leaves on the bus after boot
    }
    /// Total cycles already distributed to the peripherals.
    pub fn synced_cycles(&self) -> u64 { self.synced }

    // ---------------------------------------------------------------- waitstates
    fn set_waitcnt(&mut self, v: u16) {
        self.waitcnt = v & 0x7FFF;
        self.sram_w = 1 + NWAIT[(v & 3) as usize];
        self.rom_n = [1 + NWAIT[(v >> 2 & 3) as usize], 1 + NWAIT[(v >> 5 & 3) as usize], 1 + NWAIT[(v >> 8 & 3) as usize]];
        self.rom_s = [if v >> 4 & 1 != 0 { 2 } else { 3 }, if v >> 7 & 1 != 0 { 2 } else { 5 }, if v >> 10 & 1 != 0 { 2 } else { 9 }];
        let pf = v >> 14 & 1 != 0;
        if pf != self.prefetch { self.pf_next = u32::MAX; } // buffer starts empty when (de)activated
        self.prefetch = pf;
    }

    fn cost(&mut self, a: u32, sz: u32, seq: bool, write: bool) -> u64 {
        let r = a >> 24;
        if self.trace_mem && (5..=7).contains(&r) { self.memlog.push((self.ppu_pos + (self.cycles - self.synced) as u32, r, sz, write)); }
        (match r {
            2 => if sz == 4 { 6 } else { 3 },
            5 | 6 => if sz == 4 { 2 } else { 1 }, // ponytail: PPU/CPU VRAM+PAL contention (+1 cycle in some draw slots) not modelled
            8..=0xD => {
                let ws = ((r - 8) >> 1) as usize;
                let seq = seq && a & 0x1FFFF != 0;
                let sw = self.rom_s[ws];
                let c = if self.prefetch && !write {
                    // prefetch: a producer streams one halfword per S cycles from pf_next; the buffer holds 8
                    let need = (sz + 1) / 2;
                    if a == self.pf_next && a & 0x1FFFF != 0 {
                        let now = self.cycles;
                        let t = self.pf_last.max(now.saturating_sub((PF_CAP - 1) * sw as u64));
                        let done = t + (need * sw) as u64;
                        self.pf_last = done;
                        (done.saturating_sub(now) as u32).max(1)
                    } else {
                        let c = self.rom_n[ws] + (need - 1) * sw;
                        self.pf_last = self.cycles + c as u64 + PF_MISS_EXTRA as u64;
                        c
                    }
                } else {
                    // an idle bus cycle since the last ROM access makes the next one non-sequential
                    let seq = seq && a == self.pf_next && (self.in_dma || self.cycles == self.pf_last);
                    let first = if seq { sw } else { self.rom_n[ws] };
                    if sz == 4 { first + sw } else { first }
                };
                self.pf_next = a.wrapping_add(sz);
                if !self.prefetch { self.pf_last = self.cycles + c as u64; }
                return c as u64;
            }
            0xE | 0xF => self.sram_w,
            _ => 1,
        }) as u64
    }

    // ---------------------------------------------------------------- timed CPU/DMA API
    pub fn read8(&mut self, a: u32, seq: bool) -> u32 { self.cycles += self.cost(a, 1, seq, false); self.rd(a, 1) }
    pub fn read16(&mut self, a: u32, seq: bool) -> u32 { self.cycles += self.cost(a, 2, seq, false); self.rd(a & !1, 2) }
    pub fn read32(&mut self, a: u32, seq: bool) -> u32 { self.cycles += self.cost(a, 4, seq, false); self.rd(a & !3, 4) }
    pub fn write8(&mut self, a: u32, v: u32, seq: bool) { self.cycles += self.cost(a, 1, seq, true); self.wr(a, v, 1) }
    pub fn write16(&mut self, a: u32, v: u32, seq: bool) { self.cycles += self.cost(a, 2, seq, true); self.wr(if a >> 24 >= 0xE { a } else { a & !1 }, v, 2) }
    pub fn write32(&mut self, a: u32, v: u32, seq: bool) { self.cycles += self.cost(a, 4, seq, true); self.wr(if a >> 24 >= 0xE { a } else { a & !3 }, v, 4) }

    // ---------------------------------------------------------------- untimed memory
    fn open(&self, a: u32, sz: u32) -> u32 {
        let v = if self.in_dma { self.dma_latch } else { self.open_bus };
        match sz { 1 => (v >> ((a & 3) * 8)) & 0xFF, 2 => (v >> ((a & 2) * 8)) & 0xFFFF, _ => v }
    }

    fn rd(&mut self, a: u32, sz: u32) -> u32 {
        match a >> 24 {
            0 => {
                if a >= 0x4000 { return self.open(a, sz); }
                if self.fetch_pc < 0x4000 { self.bios_latch = ld(BIOS, (a & !3) as usize, 4); }
                let v = self.bios_latch >> ((a & 3) * 8);
                if sz == 1 { v & 0xFF } else if sz == 2 { v & 0xFFFF } else { v }
            }
            2 => ld(&self.ewram, (a & 0x3FFFF) as usize, sz),
            3 => ld(&self.iwram, (a & 0x7FFF) as usize, sz),
            4 => {
                let off = a & 0xFFFFFF;
                if off >= 0x400 { return self.open(a, sz); }
                let ob = if self.in_dma { self.dma_latch } else { self.open_bus };
                let mut r = |o: u32, sh: u32| self.io_read16(o).map_or((ob >> sh) & 0xFFFF, |v| v as u32);
                match sz {
                    1 => (r(off & !1, (off & 2) * 8) >> ((off & 1) * 8)) & 0xFF,
                    2 => r(off, (off & 2) * 8),
                    _ => r(off, 0) | r(off + 2, 16) << 16,
                }
            }
            5 => ld(&self.ppu.pal, (a & 0x3FF) as usize, sz),
            6 => {
                let o = a & 0x1FFFF;
                // observed on hardware: in bitmap modes 0x18000-0x1BFFF reads as 0 (writes dropped below)
                if (0x18000..0x1C000).contains(&o) && self.ppu.read_io(0) & 7 >= 3 { return 0; }
                ld(&self.ppu.vram, (if o >= 0x18000 { o - 0x8000 } else { o }) as usize, sz)
            }
            7 => ld(&self.ppu.oam, (a & 0x3FF) as usize, sz),
            8..=0xD => {
                if a >> 24 == 0xD && self.save.kind == save::Kind::Eeprom {
                    return self.save.eeprom_read() as u32;
                }
                let o = (a & 0x1FF_FFFF) as usize;
                if o + sz as usize <= self.rom_len { ld(&self.rom, o, sz) } else {
                    // beyond the cartridge: address bus echoes halfword index
                    let h = |o: usize| ((o >> 1) & 0xFFFF) as u32;
                    match sz { 1 => h(o) >> ((o & 1) * 8) & 0xFF, 2 => h(o), _ => h(o) | h(o + 2) << 16 }
                }
            }
            0xE | 0xF => {
                let b = self.save.read(a & 0xFFFF) as u32;
                match sz { 1 => b, 2 => b * 0x0101, _ => b * 0x0101_0101 }
            }
            _ => self.open(a, sz),
        }
    }

    fn wr(&mut self, a: u32, v: u32, sz: u32) {
        match a >> 24 {
            2 => st(&mut self.ewram, (a & 0x3FFFF) as usize, sz, v),
            3 => st(&mut self.iwram, (a & 0x7FFF) as usize, sz, v),
            4 => {
                let off = a & 0xFFFFFF;
                if off >= 0x400 { return; }
                match sz {
                    1 => { let s = (off & 1) * 8; self.io_write16(off & !1, (v & 0xFF) << s, 0xFF << s); }
                    2 => self.io_write16(off, v, 0xFFFF),
                    _ => {
                        if off == 0xA0 || off == 0xA4 { self.apu.fifo_write(((off - 0xA0) >> 2) as usize, v); }
                        else { self.io_write16(off, v & 0xFFFF, 0xFFFF); self.io_write16(off + 2, v >> 16, 0xFFFF); }
                    }
                }
            }
            5 => {
                let i = (a & 0x3FF) as usize;
                if sz == 1 { self.ppu.pal[i & !1] = v as u8; self.ppu.pal[i | 1] = v as u8; } else { st(&mut self.ppu.pal, i, sz, v); }
            }
            6 => {
                let o = a & 0x1FFFF;
                let i = (if o >= 0x18000 { o - 0x8000 } else { o }) as usize;
                if (0x18000..0x1C000).contains(&o) && self.ppu.read_io(0) & 7 >= 3 { return; }
                if sz == 1 {
                    let obj = if self.ppu.read_io(0) & 7 >= 3 { 0x14000 } else { 0x10000 };
                    if i < obj { self.ppu.vram[i & !1] = v as u8; self.ppu.vram[i | 1] = v as u8; }
                } else { st(&mut self.ppu.vram, i, sz, v); }
            }
            7 => if sz != 1 { st(&mut self.ppu.oam, (a & 0x3FF) as usize, sz, v) },
            0xD if self.save.kind == save::Kind::Eeprom => self.save.eeprom_write(v as u8),
            0xE | 0xF => self.save.write(a & 0xFFFF, (v >> ((a & (sz - 1)) * 8)) as u8),
            _ => {}
        }
    }

    // ---------------------------------------------------------------- IO
    fn io_read16(&mut self, off: u32) -> Option<u16> {
        Some(match off {
            0x10..=0x47 | 0x4C | 0x54..=0x5F | 0xA0..=0xAF => return None, // write-only / unused: open bus
            0..=0x57 => {
                if off == 4 || off == 6 { self.sync_to(self.cycles.saturating_sub(VCOUNT_ADJ)); }
                let mut v = self.ppu.read_io(off);
                // the reference raises the VBlank flag a few cycles after line 160 starts
                if off == 4 && self.ppu_pos >= 160 * 1232 && self.ppu_pos < 160 * 1232 + VBLANK_DELAY { v &= !1; }
                v
            }
            0x60..=0xA7 => self.apu.read_io(off) as u16 | (self.apu.read_io(off + 1) as u16) << 8,
            0xB0..=0xDF => if (off - 0xB0) % 12 == 10 { self.io[off as usize >> 1] & 0xFFE0 } else { return None },
            0x100..=0x10F => {
                self.sync();
                let t = &self.timers[((off - 0x100) >> 2) as usize];
                if off & 2 == 0 { if t.on && t.ctrl & 4 == 0 { t.counter.wrapping_sub((READ_ADJ >> PRESCALE[(t.ctrl & 3) as usize]) as u16) } else { t.counter } } else { t.ctrl & 0xC7 }
            }
            0x130 => !(self.keys as u16) & 0x3FF,
            0x200 => self.ie,
            0x202 => { self.sync(); self.iflag }
            0x204 => self.waitcnt,
            0x208 => self.ime,
            0x300 => self.postflg as u16,
            0x206 | 0x20A | 0x302.. => return None,
            _ => self.io[off as usize >> 1],
        })
    }

    fn io_write16(&mut self, off: u32, v: u32, mask: u32) {
        let (m, v) = (mask as u16, (v & mask) as u16);
        let merge = |old: u16| (old & !m) | v;
        match off {
            0..=0x57 => self.ppu.write_io(off, v, m),
            0x60..=0x9F => {
                if m & 0xFF != 0 { self.apu.write_io(off, v as u8); }
                if m & 0xFF00 != 0 { self.apu.write_io(off + 1, (v >> 8) as u8); }
            }
            0xA0..=0xA7 => {
                let ch = ((off - 0xA0) >> 2) as usize;
                let sh = (off & 2) * 8;
                let wm = (m as u32) << sh;
                self.fifo_buf[ch] = (self.fifo_buf[ch] & !wm) | ((v as u32) << sh);
                if off & 2 != 0 && m & 0xFF00 != 0 { self.apu.fifo_write(ch, self.fifo_buf[ch]); }
            }
            0xB0..=0xDF => {
                let i = off as usize >> 1;
                let old = self.io[i];
                self.io[i] = merge(old);
                if (off - 0xB0) % 12 == 10 { self.dma_ctrl_write(((off - 0xB0) / 12) as usize, old, self.io[i]); }
            }
            0x100..=0x10F => {
                let n = ((off - 0x100) >> 2) as usize;
                if off & 2 == 0 { self.timers[n].reload = merge(self.timers[n].reload); }
                else {
                    let t = &mut self.timers[n];
                    let c = merge(t.ctrl) & 0xC7;
                    let on = c & 0x80 != 0;
                    if on && !t.on { t.counter = t.reload; t.acc = 0; t.delay = START_DELAY; }
                    t.ctrl = c; t.on = on;
                }
            }
            0x132 => { self.io[0x99] = merge(self.io[0x99]); self.check_keypad(); }
            0x200 => self.ie = merge(self.ie) & 0x3FFF,
            0x202 => self.iflag &= !v,
            0x204 => self.set_waitcnt(merge(self.waitcnt)),
            0x208 => self.ime = merge(self.ime) & 1,
            0x300 => {
                if m & 0xFF != 0 { self.postflg = v as u8 & 1; }
                if m & 0xFF00 != 0 { self.halt = true; }
            }
            0x302.. => {}
            _ => self.io[off as usize >> 1] = merge(self.io[off as usize >> 1]),
        }
    }

    // ---------------------------------------------------------------- keypad
    pub fn set_keys(&mut self, k: u32) { self.keys = k & 0x3FF; self.check_keypad(); }
    fn check_keypad(&mut self) {
        let cnt = self.io[0x99];
        let mask = (cnt & 0x3FF) as u32;
        let hit = if cnt & 0x8000 != 0 { mask != 0 && self.keys & mask == mask } else { self.keys & mask != 0 };
        let cond = cnt & 0x4000 != 0 && hit;
        if cond && !self.key_cond { self.iflag |= 0x1000; }
        self.key_cond = cond;
    }

    // ---------------------------------------------------------------- machine stepping
    /// Distribute all cycles consumed since the last call to PPU/APU/timers (and run triggered DMAs).
    pub fn sync(&mut self) { self.sync_to(self.cycles); if self.halt && self.ie & self.iflag & 0x3FFF != 0 { self.halt = false; } }

    /// Distribute cycles up to `target` only (register reads observe the state slightly before the access ends).
    fn sync_to(&mut self, target: u64) {
        while self.synced < target {
            let d = (target - self.synced).min(256) as u32;
            let lp = self.ppu_pos % 1232;
            let d = d.min(self.next_timer_event()).min(if lp < 1006 { 1006 - lp } else { 1232 - lp });
            self.synced += d as u64;
            self.tick(d);
        }
    }

    /// Fast-forward while halted: burn up to `max` cycles until the next event.
    pub fn halt_skip(&mut self, max: u64) {
        let d = (max.min(256) as u32).min(self.next_timer_event()).max(1);
        self.cycles += d as u64;
        self.sync();
    }

    fn next_timer_event(&self) -> u32 {
        let mut m = 256u32;
        for (i, t) in self.timers.iter().enumerate() {
            if !t.on || (t.ctrl & 4 != 0 && i > 0) { continue; }
            let sh = PRESCALE[(t.ctrl & 3) as usize];
            let need = (((0x10000 - t.counter as u32) << sh).saturating_sub(t.acc)) + t.delay;
            m = m.min(need.max(1));
        }
        m
    }

    fn tick(&mut self, d: u32) {
        let ev = self.ppu.tick(d);
        self.ppu_pos = (self.ppu_pos + d) % 280_896;
        self.iflag |= ev.irq & 7;
        self.apu.tick(d);
        self.timers_tick(d);
        if ev.vblank_start { self.frame_done = true; self.dma_trigger(1); }
        if ev.hblank_start {
            let vc = self.ppu.read_io(6) & 0xFF;
            if vc < 160 { self.dma_trigger(2); }
            if (2..162).contains(&vc) { self.dma_trigger(3); if vc == 161 { self.io[0xDE >> 1] &= !0x8000; } }
        }
        self.check_keypad();
    }

    fn timers_tick(&mut self, cyc: u32) {
        let mut carry = 0u32;
        let mut fifo_req = 0u8;
        for i in 0..4 {
            let t = &mut self.timers[i];
            if !t.on { carry = 0; continue; }
            let ticks = if t.ctrl & 4 != 0 && i > 0 { carry } else {
                let sh = PRESCALE[(t.ctrl & 3) as usize];
                let skip = t.delay.min(cyc);
                t.delay -= skip;
                t.acc += cyc - skip;
                let k = t.acc >> sh;
                t.acc &= (1 << sh) - 1;
                k
            };
            carry = 0;
            let total = t.counter as u32 + ticks;
            if total < 0x10000 { t.counter = total as u16; continue; }
            let period = 0x10000 - t.reload as u32;
            let over = total - 0x10000;
            let n = 1 + over / period;
            t.counter = (t.reload as u32 + over % period) as u16;
            carry = n;
            if t.ctrl & 0x40 != 0 { self.iflag |= 8 << i; }
            if i < 2 { fifo_req |= self.apu.timer_overflow(i, n); }
        }
        for ch in 0..2 { if fifo_req >> ch & 1 != 0 { self.dma_fifo(ch); } }
    }

    // ---------------------------------------------------------------- DMA
    fn dma_ctrl_write(&mut self, n: usize, old: u16, new: u16) {
        if new & 0x8000 == 0 || old & 0x8000 != 0 { return; }
        let r = |o: usize| self.io[(0xB0 + 12 * n + o) >> 1] as u32;
        let (sad, dad, cnt) = (r(0) | r(2) << 16, r(4) | r(6) << 16, r(8));
        let d = &mut self.dma[n];
        d.src = sad & if n == 0 { 0x07FF_FFFF } else { 0x0FFF_FFFF };
        d.dst = dad & if n < 3 { 0x07FF_FFFF } else { 0x0FFF_FFFF };
        d.left = Self::dma_count(n, cnt);
        if new >> 12 & 3 == 0 { self.cycles += 2; self.dma_pending |= 1 << n; self.dma_run_pending(); }
    }
    fn dma_count(n: usize, cnt: u32) -> u32 { if cnt == 0 { if n == 3 { 0x10000 } else { 0x4000 } } else { cnt & if n == 3 { 0xFFFF } else { 0x3FFF } } }

    fn dma_trigger(&mut self, timing: u16) {
        for n in 0..4 {
            let c = self.io[(0xBA + 12 * n) >> 1];
            if c & 0x8000 != 0 && c >> 12 & 3 == timing && (timing != 3 || n == 3) { self.dma_pending |= 1 << n; }
        }
        self.dma_run_pending();
    }
    fn dma_fifo(&mut self, ch: usize) {
        for n in 1..3 {
            let c = self.io[(0xBA + 12 * n) >> 1];
            if c & 0x8000 != 0 && c >> 12 & 3 == 3 && self.dma[n].dst & !3 == 0x0400_00A0 + 4 * ch as u32 { self.dma_pending |= 1 << n; self.fifo_mask |= 1 << n; }
        }
        self.dma_run_pending();
    }

    /// Run requested channels, lowest number (highest priority) first; channels requested meanwhile are picked up too.
    fn dma_run_pending(&mut self) {
        if self.in_dma { return; }
        while self.dma_pending != 0 {
            let n = self.dma_pending.trailing_zeros() as usize;
            self.dma_pending &= !(1 << n);
            let fifo = self.fifo_mask >> n & 1 != 0;
            self.fifo_mask &= !(1 << n);
            if self.io[(0xBA + 12 * n) >> 1] & 0x8000 != 0 { self.run_dma(n, fifo); }
        }
    }

    fn run_dma(&mut self, n: usize, fifo: bool) {
        self.in_dma = true;
        let ci = (0xBA + 12 * n) >> 1;
        let ctrl = self.io[ci];
        let word = fifo || ctrl & 0x400 != 0;
        let sz = if word { 4 } else { 2 };
        let (dc, sc) = ((ctrl >> 5 & 3) as u32, (ctrl >> 7 & 3) as u32);
        let mut d = self.dma[n];
        let count = if fifo { 4 } else { d.left };
        if d.dst >> 24 == 0xD { self.save.eeprom_hint(count); }
        let mut aborted = false;
        for i in 0..count {
            if self.io[ci] & 0x8000 == 0 { aborted = true; break; }
            let seq = i > 0;
            d.src &= !(sz - 1); d.dst &= !(sz - 1);
            let v = if d.src < 0x0200_0000 || d.src >= 0x1000_0000 { self.dma_latch }
                else if word { self.read32(d.src, seq) } else { self.read16(d.src, seq) };
            if d.src >= 0x0200_0000 && d.src < 0x1000_0000 { self.dma_latch = if word { v } else { v | v << 16 }; }
            if word { self.write32(d.dst, v, seq) } else { self.write16(d.dst, v, seq) }
            // observed: Game Pak sources ignore 'fixed' and keep incrementing
            d.src = match if (sc == 2 || sc == 1) && (0x0800_0000..0x0E00_0000).contains(&d.src) { 0 } else { sc } { 1 => d.src.wrapping_sub(sz), 2 => d.src, _ => d.src.wrapping_add(sz) };
            if !fifo { d.dst = match dc { 1 => d.dst.wrapping_sub(sz), 2 => d.dst, _ => d.dst.wrapping_add(sz) }; }
        }
        if aborted { self.dma[n] = d; self.in_dma = false; return; }
        let timing = ctrl >> 12 & 3;
        if ctrl & 0x4000 != 0 && !fifo { self.iflag |= 0x100 << n; }
        if fifo || (ctrl & 0x200 != 0 && timing != 0) {
            if !fifo {
                let r = |o: usize| self.io[(0xB0 + 12 * n + o) >> 1] as u32;
                d.left = Self::dma_count(n, r(8));
                if dc == 3 { d.dst = (r(4) | r(6) << 16) & if n < 3 { 0x07FF_FFFF } else { 0x0FFF_FFFF }; }
            }
        } else {
            self.io[ci] &= !0x8000;
        }
        self.dma[n] = d;
        self.in_dma = false;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn bus() -> Bus { let mut b = Bus::new(); b.rom_len = 0x100; b.reset(); b }

    #[test]
    fn mirrors_and_widths() {
        let mut b = bus();
        b.write32(0x0300_0000, 0xAABBCCDD, false);
        assert_eq!(b.read32(0x0300_8000, false), 0xAABBCCDD);
        assert_eq!(b.read8(0x0300_7FE1, false), 0); // untouched
        b.write16(0x0200_0002, 0x1234, false);
        assert_eq!(b.read16(0x0204_0002, false), 0x1234);
        b.write8(0x0500_0001, 0x7F, false);
        assert_eq!(b.read16(0x0500_0000, false), 0x7F7F);
    }

    #[test]
    fn waitstates() {
        let mut b = bus();
        let c = b.cycles; b.read32(0x0200_0000, false); assert_eq!(b.cycles - c, 6);
        let c = b.cycles; b.read16(0x0800_0000, false); assert_eq!(b.cycles - c, 5);
        let c = b.cycles; b.read16(0x0800_0002, true); assert_eq!(b.cycles - c, 3);
        let c = b.cycles; b.read32(0x0800_0004, true); assert_eq!(b.cycles - c, 6);
    }

    #[test]
    fn timer_irq_and_cascade() {
        let mut b = bus();
        b.write32(0x0400_0100, 0xFFF0 | 0xC1 << 16, false); // reload FFF0, irq, on, /64? (ctrl 0xC1)
        b.write32(0x0400_0104, 0xFFFE | 0x84 << 16, false); // cascade, on
        b.idle(64 * 16 + 1); b.sync();
        assert_eq!(b.iflag & 8, 8);
        assert_eq!(b.timers[1].counter, 0xFFFF);
    }

    #[test]
    fn dma_immediate_and_ifack() {
        let mut b = bus();
        for i in 0..4u32 { b.write32(0x0200_0000 + i * 4, 0x01010101 * (i + 1), false); }
        b.write32(0x0400_00D4, 0x0200_0000, false);
        b.write32(0x0400_00D8, 0x0300_0000, false);
        b.write32(0x0400_00DC, 4 | (0x8000 | 0x4000 | 0x400) << 16, false);
        assert_eq!(b.read32(0x0300_000C, false), 0x04040404);
        assert_eq!(b.iflag & 0x800, 0x800);
        b.write16(0x0400_0202, 0x800, false);
        assert_eq!(b.iflag, 0);
        assert_eq!(b.io[0xDE >> 1] & 0x8000, 0);
    }

    #[test]
    fn flash_and_eeprom() {
        let mut s = Save::new(save::Kind::Flash64);
        for (o, v) in [(0x5555, 0xAA), (0x2AAA, 0x55), (0x5555, 0xA0), (0x123, 0x42)] { s.write(o, v); }
        assert_eq!(s.read(0x123), 0x42);
        let mut e = Save::new(save::Kind::Eeprom);
        e.eeprom_hint(73);
        let mut w = vec![1, 0, 0, 0, 0, 0, 1, 1];
        for i in 0..64 { w.push(((0xA5u8 >> (7 - i % 8)) & 1) as u8); }
        w.push(0);
        for b in w { e.eeprom_write(b); }
        for b in [1, 1, 0, 0, 0, 0, 1, 1, 0] { e.eeprom_write(b); }
        let bits: Vec<u16> = (0..68).map(|_| e.eeprom_read()).collect();
        assert_eq!(&bits[4..12], &[1, 0, 1, 0, 0, 1, 0, 1]);
    }
}
