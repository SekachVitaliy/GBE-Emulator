//! ARM7TDMI core: ARM + THUMB, banked registers, exceptions.
//!
//! Model: `r[15]` always holds the pipeline-visible PC (instr + 8 in ARM, instr + 4 in
//! THUMB). Each instruction pays its own fetch; a pipeline flush pays the two refill
//! fetches (N + S) so branches cost 2S+1N in total like on hardware.
use crate::bus::Bus;

/// Memory/timing interface the core needs (implemented for `Bus`).
pub trait CpuBus {
    fn read8(&mut self, a: u32, seq: bool) -> u32;
    fn read16(&mut self, a: u32, seq: bool) -> u32;
    fn read32(&mut self, a: u32, seq: bool) -> u32;
    fn write8(&mut self, a: u32, v: u32, seq: bool);
    fn write16(&mut self, a: u32, v: u32, seq: bool);
    fn write32(&mut self, a: u32, v: u32, seq: bool);
    fn idle(&mut self, c: u32);
    fn irq_line(&self) -> bool;
    fn halted(&self) -> bool;
    /// Tell the bus the address/opcode of the instruction being executed (BIOS protection, open bus).
    fn note_fetch(&mut self, _pc: u32, _op: u32) {}
    fn note_pc(&mut self, _pc: u32) {}
    /// Untimed peek of the word at `a` (ROM only); used to set the open-bus value.
    fn peek32(&mut self, _a: u32) -> Option<u32> { None }
    fn set_open(&mut self, _v: u32) {}
    fn fetch16(&mut self, a: u32, seq: bool) -> u32 { self.read16(a, seq) }
    fn fetch32(&mut self, a: u32, seq: bool) -> u32 { self.read32(a, seq) }
}

/// Any non-ROM bus access makes the next ROM fetch non-sequential (idle(0) marks the break).
#[inline(always)]
fn brk(b: &mut Bus, a: u32) {
    if (a >> 24).wrapping_sub(8) >= 6 { Bus::idle(b, 0); }
}
impl CpuBus for Bus {
    #[inline] fn read8(&mut self, a: u32, s: bool) -> u32 { let v = Bus::read8(self, a, s); brk(self, a); v }
    #[inline] fn read16(&mut self, a: u32, s: bool) -> u32 { let v = Bus::read16(self, a, s); brk(self, a); v }
    #[inline] fn read32(&mut self, a: u32, s: bool) -> u32 { let v = Bus::read32(self, a, s); brk(self, a); v }
    #[inline] fn write8(&mut self, a: u32, v: u32, s: bool) { Bus::write8(self, a, v, s); brk(self, a) }
    #[inline] fn write16(&mut self, a: u32, v: u32, s: bool) { Bus::write16(self, a, v, s); brk(self, a) }
    #[inline] fn write32(&mut self, a: u32, v: u32, s: bool) { Bus::write32(self, a, v, s); brk(self, a) }
    #[inline] fn idle(&mut self, c: u32) { Bus::idle(self, c) }
    #[inline] fn irq_line(&self) -> bool { Bus::irq_line(self) }
    #[inline] fn halted(&self) -> bool { Bus::halted(self) }
    #[inline] fn note_pc(&mut self, pc: u32) { self.fetch_pc = pc; }
    #[inline] fn set_open(&mut self, v: u32) { self.open_bus = v; }
    #[inline] fn peek32(&mut self, a: u32) -> Option<u32> {
        let o = (a & 0x1FF_FFFF) as usize;
        if (a >> 24).wrapping_sub(8) < 6 && o + 4 <= self.rom_len {
            Some(u32::from_le_bytes([self.rom[o], self.rom[o + 1], self.rom[o + 2], self.rom[o + 3]]))
        } else { None }
    }
    #[inline] fn note_fetch(&mut self, pc: u32, op: u32) { self.fetch_pc = pc; self.open_bus = op; }
}

const N: u32 = 1 << 31;
const Z: u32 = 1 << 30;
const C: u32 = 1 << 29;
const V: u32 = 1 << 28;
const FT: u32 = 1 << 5;
const FI: u32 = 1 << 7;

const M_USR: u32 = 0x10;
const M_FIQ: u32 = 0x11;
const M_IRQ: u32 = 0x12;
const M_SVC: u32 = 0x13;
const M_ABT: u32 = 0x17;
const M_UND: u32 = 0x1B;

#[inline]
fn bank(mode: u32) -> usize {
    match mode & 0x1F {
        0x11 => 1,
        0x12 => 2,
        0x13 => 3,
        0x17 => 4,
        0x1B => 5,
        _ => 0,
    }
}

/// Condition table: bit `flags(NZCV)` of COND[c] says whether condition c passes.
const COND: [u16; 16] = {
    let mut t = [0u16; 16];
    let mut c = 0;
    while c < 16 {
        let mut f = 0;
        while f < 16 {
            let n = f & 8 != 0;
            let z = f & 4 != 0;
            let cc = f & 2 != 0;
            let v = f & 1 != 0;
            let ok = match c {
                0 => z,
                1 => !z,
                2 => cc,
                3 => !cc,
                4 => n,
                5 => !n,
                6 => v,
                7 => !v,
                8 => cc && !z,
                9 => !cc || z,
                10 => n == v,
                11 => n != v,
                12 => !z && n == v,
                13 => z || n != v,
                14 => true,
                _ => false,
            };
            if ok {
                t[c] |= 1 << f;
            }
            f += 1;
        }
        c += 1;
    }
    t
};

#[derive(Clone)]
pub struct Cpu {
    pub r: [u32; 16],
    pub cpsr: u32,
    spsr: [u32; 6],
    bank_sp: [u32; 6],
    bank_lr: [u32; 6],
    fiq_r: [u32; 5],
    usr_r: [u32; 5],
    flushed: bool,
    cold: bool,
    step_thumb: bool,
    wasted: bool,
    irq_prev: bool,
    pipe: [u32; 2],
}

#[inline]
fn shift_imm(typ: u32, v: u32, amt: u32, c: bool) -> (u32, bool) {
    match typ {
        0 => {
            if amt == 0 { (v, c) } else { (v << amt, (v >> (32 - amt)) & 1 != 0) }
        }
        1 => {
            if amt == 0 { (0, v >> 31 != 0) } else { (v >> amt, (v >> (amt - 1)) & 1 != 0) }
        }
        2 => {
            if amt == 0 {
                (((v as i32) >> 31) as u32, v >> 31 != 0)
            } else {
                (((v as i32) >> amt) as u32, (v >> (amt - 1)) & 1 != 0)
            }
        }
        _ => {
            if amt == 0 {
                ((v >> 1) | ((c as u32) << 31), v & 1 != 0)
            } else {
                (v.rotate_right(amt), (v >> (amt - 1)) & 1 != 0)
            }
        }
    }
}

#[inline]
fn shift_reg(typ: u32, v: u32, amt: u32, c: bool) -> (u32, bool) {
    if amt == 0 {
        return (v, c);
    }
    match typ {
        0 => {
            if amt < 32 { (v << amt, (v >> (32 - amt)) & 1 != 0) }
            else if amt == 32 { (0, v & 1 != 0) } else { (0, false) }
        }
        1 => {
            if amt < 32 { (v >> amt, (v >> (amt - 1)) & 1 != 0) }
            else if amt == 32 { (0, v >> 31 != 0) } else { (0, false) }
        }
        2 => {
            if amt < 32 { (((v as i32) >> amt) as u32, (v >> (amt - 1)) & 1 != 0) }
            else { (((v as i32) >> 31) as u32, v >> 31 != 0) }
        }
        _ => {
            let a = amt & 31;
            if a == 0 { (v, v >> 31 != 0) } else { (v.rotate_right(a), (v >> (a - 1)) & 1 != 0) }
        }
    }
}

#[inline]
fn mul_cycles(rs: u32, signed: bool) -> u32 {
    let x = if signed && (rs as i32) < 0 { !rs } else { rs };
    if x >> 8 == 0 { 1 } else if x >> 16 == 0 { 2 } else if x >> 24 == 0 { 3 } else { 4 }
}

impl Cpu {
    pub fn new() -> Self {
        let mut c = Cpu {
            r: [0; 16],
            cpsr: 0xD3,
            spsr: [0; 6],
            bank_sp: [0; 6],
            bank_lr: [0; 6],
            fiq_r: [0; 5],
            usr_r: [0; 5],
            flushed: false,
            cold: true,
            step_thumb: false,
            wasted: false,
            irq_prev: false,
            pipe: [0; 2],
        };
        c.r[15] = 8;
        c
    }
    pub fn reset(&mut self) {
        *self = Cpu::new();
    }

    /// Run one instruction (or take an IRQ).
    pub fn step(&mut self, bus: &mut Bus) {
        self.step_g(bus)
    }

    // ---------------------------------------------------------------- state helpers
    #[inline]
    fn thumb(&self) -> bool {
        self.cpsr & FT != 0
    }

    fn switch_mode(&mut self, new: u32) {
        let old = self.cpsr & 0x1F;
        let (ob, nb) = (bank(old), bank(new));
        if ob == nb {
            return;
        }
        self.bank_sp[ob] = self.r[13];
        self.bank_lr[ob] = self.r[14];
        if old == M_FIQ {
            self.fiq_r.copy_from_slice(&self.r[8..13]);
            self.r[8..13].copy_from_slice(&self.usr_r);
        }
        if new & 0x1F == M_FIQ {
            self.usr_r.copy_from_slice(&self.r[8..13]);
            self.r[8..13].copy_from_slice(&self.fiq_r);
        }
        self.r[13] = self.bank_sp[nb];
        self.r[14] = self.bank_lr[nb];
    }

    fn set_cpsr(&mut self, v: u32) {
        self.switch_mode(v);
        self.cpsr = v;
    }

    fn restore_spsr(&mut self) {
        let b = bank(self.cpsr);
        if b != 0 {
            let s = self.spsr[b];
            self.set_cpsr(s);
        }
    }

    fn user_reg(&self, i: usize) -> u32 {
        let m = self.cpsr & 0x1F;
        if bank(m) == 0 { return self.r[i]; }
        match i {
            8..=12 if m == M_FIQ => self.usr_r[i - 8],
            13 => self.bank_sp[0],
            14 => self.bank_lr[0],
            _ => self.r[i],
        }
    }
    fn set_user_reg(&mut self, i: usize, v: u32) {
        let m = self.cpsr & 0x1F;
        if bank(m) == 0 { self.r[i] = v; return; }
        match i {
            8..=12 if m == M_FIQ => self.usr_r[i - 8] = v,
            13 => self.bank_sp[0] = v,
            14 => self.bank_lr[0] = v,
            _ => self.r[i] = v,
        }
    }

    #[inline]
    fn cond_ok(&self, c: u32) -> bool {
        COND[c as usize] >> (self.cpsr >> 28) & 1 != 0
    }

    #[inline]
    fn set_nz(&mut self, v: u32) {
        self.cpsr = (self.cpsr & !(N | Z)) | (v & N) | if v == 0 { Z } else { 0 };
    }
    #[inline]
    fn set_c(&mut self, c: bool) {
        self.cpsr = (self.cpsr & !C) | if c { C } else { 0 };
    }

    /// a + b + cin with optional flag update.
    #[inline]
    fn adc(&mut self, a: u32, b: u32, cin: u32, s: bool) -> u32 {
        let r64 = a as u64 + b as u64 + cin as u64;
        let r = r64 as u32;
        if s {
            let v = (!(a ^ b) & (a ^ r)) >> 31;
            self.cpsr = (self.cpsr & !(N | Z | C | V))
                | (r & N)
                | if r == 0 { Z } else { 0 }
                | if r64 >> 32 != 0 { C } else { 0 }
                | (v << 28);
        }
        r
    }

    /// Refill the two-stage pipeline from `v` (N + S fetch).
    fn refill<B: CpuBus>(&mut self, b: &mut B, v: u32) {
        if self.thumb() {
            let pc = v & !1;
            self.r[15] = pc.wrapping_add(4);
            b.note_pc(pc);
            self.pipe[0] = b.fetch16(pc, false) & 0xFFFF;
            self.pipe[1] = b.fetch16(pc.wrapping_add(2), true) & 0xFFFF;
        } else {
            let pc = v & !3;
            self.r[15] = pc.wrapping_add(8);
            b.note_pc(pc);
            self.pipe[0] = b.fetch32(pc, false);
            self.pipe[1] = b.fetch32(pc.wrapping_add(4), true);
        }
        self.flushed = true;
    }

    /// Branch: the fetch already in flight (at r15) is wasted, then the pipeline refills.
    fn set_pc<B: CpuBus>(&mut self, b: &mut B, v: u32) {
        self.waste(b);
        self.refill(b, v);
    }

    /// The wasted in-flight fetch; loads into PC issue it before their data cycles.
    fn waste<B: CpuBus>(&mut self, b: &mut B) {
        if !self.wasted {
            self.wasted = true;
            if self.thumb() { b.fetch16(self.r[15], true); } else { b.fetch32(self.r[15], true); }
        }
    }

    fn exception<B: CpuBus>(&mut self, b: &mut B, mode: u32, vector: u32, lr: u32) {
        let old = self.cpsr;
        self.spsr[bank(mode)] = old;
        self.set_cpsr((old & !0x3F) | mode | FI);
        self.r[14] = lr;
        let was_t = self.cpsr & FT != 0;
        self.cpsr &= !FT;
        if mode == M_IRQ { if was_t { b.fetch16(self.r[15], true); } else { b.fetch32(self.r[15], true); } self.wasted = true; b.idle(2); } else { self.wasted = true; b.idle(1); }
        self.set_pc(b, vector);
    }

    // ---------------------------------------------------------------- step
    pub fn step_g<B: CpuBus>(&mut self, b: &mut B) {
        if b.halted() {
            b.idle(1);
            return;
        }
        if self.cold {
            self.cold = false;
            let pc = self.r[15].wrapping_sub(8);
            b.note_pc(pc);
            self.refill(b, pc);
        }
        self.flushed = false;
        self.wasted = false;
        self.step_thumb = self.cpsr & FT != 0;
        let irq = b.irq_line();
        let take = irq;
        if self.cpsr & FI == 0 && take {
            // next instruction = r15-8 (ARM) / r15-4 (THUMB); LR = next + 4
            let lr = if self.step_thumb { self.r[15] } else { self.r[15] - 4 };
            self.exception(b, M_IRQ, 0x18, lr);
            return;
        }
        let op = self.pipe[0];
        self.pipe[0] = self.pipe[1];
        // The opcode fetch for the pipeline happens after the instruction's own bus cycles.
        if self.step_thumb {
            b.note_pc(self.r[15].wrapping_sub(4));
            if let Some(w) = b.peek32(self.r[15] & !3) {
                let h = if self.r[15] & 2 != 0 { w >> 16 } else { w & 0xFFFF };
                b.set_open(h | h << 16);
            }
            self.exec_thumb(b, op);
            if !self.flushed {
                let nf = b.fetch16(self.r[15], true) & 0xFFFF;
                self.pipe[1] = nf;
                b.note_fetch(self.r[15], nf | nf << 16);
                self.r[15] = self.r[15].wrapping_add(2);
            }
        } else {
            b.note_pc(self.r[15].wrapping_sub(8));
            if let Some(w) = b.peek32(self.r[15]) { b.set_open(w); }
            if self.cond_ok(op >> 28) {
                self.exec_arm(b, op);
            }
            if !self.flushed {
                let nf = b.fetch32(self.r[15], true);
                self.pipe[1] = nf;
                b.note_fetch(self.r[15], nf);
                self.r[15] = self.r[15].wrapping_add(4);
            }
        }
    }

    // ---------------------------------------------------------------- memory helpers
    #[inline]
    fn ld32<B: CpuBus>(&mut self, b: &mut B, a: u32, seq: bool) -> u32 {
        b.read32(a, seq).rotate_right((a & 3) * 8)
    }
    #[inline]
    fn ld16<B: CpuBus>(&mut self, b: &mut B, a: u32, seq: bool) -> u32 {
        (b.read16(a, seq) & 0xFFFF).rotate_right((a & 1) * 8)
    }
    #[inline]
    fn ld16s<B: CpuBus>(&mut self, b: &mut B, a: u32, seq: bool) -> u32 {
        if a & 1 != 0 {
            b.read8(a, seq) as u8 as i8 as u32
        } else {
            b.read16(a, seq) as u16 as i16 as u32
        }
    }
    #[inline]
    fn ld8s<B: CpuBus>(&mut self, b: &mut B, a: u32, seq: bool) -> u32 {
        b.read8(a, seq) as u8 as i8 as u32
    }

    // ---------------------------------------------------------------- ARM
    fn exec_arm<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        match (op >> 25) & 7 {
            0 => {
                if op & 0x90 == 0x90 {
                    if op & 0x60 == 0 {
                        // multiply / swap
                        if op & 0x0100_0000 == 0 {
                            if op & 0x0080_0000 == 0 { self.arm_mul(b, op) } else { self.arm_mull(b, op) }
                        } else {
                            self.arm_swp(b, op)
                        }
                    } else {
                        self.arm_half(b, op)
                    }
                } else if op & 0x0FFF_FFF0 == 0x012F_FF10 {
                    let t = self.r[(op & 15) as usize];
                    if t & 1 != 0 { self.cpsr |= FT } else { self.cpsr &= !FT }
                    self.set_pc(b, t);
                } else if op & 0x0190_0000 == 0x0100_0000 {
                    self.arm_psr(b, op)
                } else {
                    self.arm_dp(b, op)
                }
            }
            1 => {
                if op & 0x0190_0000 == 0x0100_0000 {
                    self.arm_psr(b, op)
                } else {
                    self.arm_dp(b, op)
                }
            }
            2 => self.arm_sdt(b, op),
            3 => {
                if op & 0x10 != 0 { self.arm_undef(b) } else { self.arm_sdt(b, op) }
            }
            4 => self.arm_block(b, op),
            5 => {
                let off = (((op << 8) as i32) >> 6) as u32;
                if op & (1 << 24) != 0 {
                    self.r[14] = self.r[15].wrapping_sub(4);
                }
                let t = self.r[15].wrapping_add(off);
                self.set_pc(b, t);
            }
            6 => self.arm_undef(b),
            _ => {
                if op & (1 << 24) != 0 {
                    let lr = self.r[15].wrapping_sub(4);
                    self.exception(b, M_SVC, 0x08, lr);
                } else {
                    self.arm_undef(b)
                }
            }
        }
    }

    fn arm_undef<B: CpuBus>(&mut self, b: &mut B) {
        let lr = self.r[15].wrapping_sub(4);
        self.exception(b, M_UND, 0x04, lr);
    }

    fn arm_dp<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let opc = (op >> 21) & 15;
        let s = op & (1 << 20) != 0;
        let rn = ((op >> 16) & 15) as usize;
        let rd = ((op >> 12) & 15) as usize;
        let mut carry = self.cpsr & C != 0;
        let mut a = self.r[rn];
        let o2;
        if op & (1 << 25) != 0 {
            let rot = ((op >> 8) & 15) * 2;
            o2 = (op & 0xFF).rotate_right(rot);
            if rot != 0 {
                carry = o2 >> 31 != 0;
            }
        } else {
            let rm = (op & 15) as usize;
            let typ = (op >> 5) & 3;
            if op & 0x10 != 0 {
                b.idle(1);
                let amt = self.r[((op >> 8) & 15) as usize] & 0xFF;
                let mut v = self.r[rm];
                if rm == 15 { v = v.wrapping_add(4); }
                if rn == 15 { a = a.wrapping_add(4); }
                let (x, c) = shift_reg(typ, v, amt, carry);
                o2 = x;
                carry = c;
            } else {
                let (x, c) = shift_imm(typ, self.r[rm], (op >> 7) & 31, carry);
                o2 = x;
                carry = c;
            }
        }
        let wr = !(8..=11).contains(&opc);
        // flags are not touched by ALU when Rd=PC with S (CPSR <- SPSR instead)
        let sf = s && !(wr && rd == 15);
        let cin = (self.cpsr & C != 0) as u32;
        let res = match opc {
            0 | 8 => a & o2,
            1 | 9 => a ^ o2,
            2 | 10 => self.adc(a, !o2, 1, sf),
            3 => self.adc(o2, !a, 1, sf),
            4 | 11 => self.adc(a, o2, 0, sf),
            5 => self.adc(a, o2, cin, sf),
            6 => self.adc(a, !o2, cin, sf),
            7 => self.adc(o2, !a, cin, sf),
            12 => a | o2,
            13 => o2,
            14 => a & !o2,
            _ => !o2,
        };
        if sf && (opc < 2 || opc == 8 || opc == 9 || opc >= 12) {
            self.set_nz(res);
            self.set_c(carry);
        }
        if !wr && rd == 15 {
            self.restore_spsr(); // TSTP/TEQP/CMPP/CMNP
        }
        if wr {
            if rd == 15 {
                if s {
                    self.restore_spsr();
                }
                self.set_pc(b, res);
            } else {
                self.r[rd] = res;
            }
        }
    }

    fn arm_psr<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let spsr = op & (1 << 22) != 0;
        if op & (1 << 21) == 0 {
            // MRS
            let rd = ((op >> 12) & 15) as usize;
            let bk = bank(self.cpsr);
            self.r[rd] = if spsr && bk != 0 { self.spsr[bk] } else { self.cpsr };
            return;
        }
        // MSR
        let v = if op & (1 << 25) != 0 {
            (op & 0xFF).rotate_right(((op >> 8) & 15) * 2)
        } else {
            self.r[(op & 15) as usize]
        };
        let mut mask = 0u32;
        if op & (1 << 19) != 0 { mask |= 0xFF00_0000; }
        if op & (1 << 18) != 0 { mask |= 0x00FF_0000; }
        if op & (1 << 17) != 0 { mask |= 0x0000_FF00; }
        if op & (1 << 16) != 0 { mask |= 0x0000_00FF; }
        let _ = b;
        if spsr {
            let bk = bank(self.cpsr);
            if bk != 0 {
                self.spsr[bk] = (self.spsr[bk] & !mask) | (v & mask);
            }
        } else {
            if self.cpsr & 0x1F == M_USR {
                mask &= 0xFF00_0000;
            }
            let n = (self.cpsr & !mask) | (v & mask);
            self.set_cpsr(n);
        }
    }

    fn arm_mul<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let rd = ((op >> 16) & 15) as usize;
        let rn = ((op >> 12) & 15) as usize;
        let rs = self.r[((op >> 8) & 15) as usize];
        let rm = self.r[(op & 15) as usize];
        let mut res = rm.wrapping_mul(rs);
        let mut m = mul_cycles(rs, true);
        if op & (1 << 21) != 0 {
            res = res.wrapping_add(self.r[rn]);
            m += 1;
        }
        b.idle(m);
        self.r[rd] = res;
        if op & (1 << 20) != 0 {
            self.set_nz(res);
        }
    }

    fn arm_mull<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let hi = ((op >> 16) & 15) as usize;
        let lo = ((op >> 12) & 15) as usize;
        let rs = self.r[((op >> 8) & 15) as usize];
        let rm = self.r[(op & 15) as usize];
        let signed = op & (1 << 22) != 0;
        let mut res: u64 = if signed {
            (rm as i32 as i64).wrapping_mul(rs as i32 as i64) as u64
        } else {
            (rm as u64) * (rs as u64)
        };
        let mut m = mul_cycles(rs, signed) + 1;
        if op & (1 << 21) != 0 {
            let acc = ((self.r[hi] as u64) << 32) | self.r[lo] as u64;
            res = res.wrapping_add(acc);
            m += 1;
        }
        b.idle(m);
        self.r[lo] = res as u32;
        self.r[hi] = (res >> 32) as u32;
        if op & (1 << 20) != 0 {
            self.cpsr = (self.cpsr & !(N | Z)) | ((res >> 32) as u32 & N) | if res == 0 { Z } else { 0 };
        }
    }

    fn arm_swp<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let rn = ((op >> 16) & 15) as usize;
        let rd = ((op >> 12) & 15) as usize;
        let rm = self.r[(op & 15) as usize];
        let a = self.r[rn];
        let t;
        if op & (1 << 22) != 0 {
            t = b.read8(a, false) & 0xFF;
            b.write8(a, rm & 0xFF, false);
        } else {
            t = self.ld32(b, a, false);
            b.write32(a, rm, false);
        }
        b.idle(1);
        self.r[rd] = t;
    }

    fn arm_half<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let p = op & (1 << 24) != 0;
        let u = op & (1 << 23) != 0;
        let w = op & (1 << 21) != 0;
        let l = op & (1 << 20) != 0;
        let rn = ((op >> 16) & 15) as usize;
        let rd = ((op >> 12) & 15) as usize;
        let sh = (op >> 5) & 3;
        if !l && sh != 1 {
            return self.arm_undef(b);
        }
        let off = if op & (1 << 22) != 0 {
            ((op >> 4) & 0xF0) | (op & 15)
        } else {
            self.r[(op & 15) as usize]
        };
        let base = self.r[rn];
        let moved = if u { base.wrapping_add(off) } else { base.wrapping_sub(off) };
        let addr = if p { moved } else { base };
        if l {
            if rd == 15 { self.waste(b); }
            let v = match sh {
                1 => self.ld16(b, addr, false),
                2 => self.ld8s(b, addr, false),
                _ => self.ld16s(b, addr, false),
            };
            b.idle(1);
            if w || !p { self.r[rn] = moved; }
            if rd == 15 { self.set_pc(b, v) } else { self.r[rd] = v }
        } else {
            let mut v = self.r[rd];
            if rd == 15 { v = v.wrapping_add(4); }
            b.write16(addr, v & 0xFFFF, false);
            if w || !p { self.r[rn] = moved; }
        }
    }

    fn arm_sdt<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let p = op & (1 << 24) != 0;
        let u = op & (1 << 23) != 0;
        let byte = op & (1 << 22) != 0;
        let w = op & (1 << 21) != 0;
        let l = op & (1 << 20) != 0;
        let rn = ((op >> 16) & 15) as usize;
        let rd = ((op >> 12) & 15) as usize;
        let off = if op & (1 << 25) != 0 {
            let c = self.cpsr & C != 0;
            shift_imm((op >> 5) & 3, self.r[(op & 15) as usize], (op >> 7) & 31, c).0
        } else {
            op & 0xFFF
        };
        let base = self.r[rn];
        let moved = if u { base.wrapping_add(off) } else { base.wrapping_sub(off) };
        let addr = if p { moved } else { base };
        if l {
            if rd == 15 { self.waste(b); }
            let v = if byte { b.read8(addr, false) & 0xFF } else { self.ld32(b, addr, false) };
            b.idle(1);
            if w || !p { self.r[rn] = moved; }
            if rd == 15 { self.set_pc(b, v) } else { self.r[rd] = v }
        } else {
            let mut v = self.r[rd];
            if rd == 15 { v = v.wrapping_add(4); }
            if byte { b.write8(addr, v & 0xFF, false) } else { b.write32(addr, v, false) }
            if w || !p { self.r[rn] = moved; }
        }
    }

    fn arm_block<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let p = op & (1 << 24) != 0;
        let u = op & (1 << 23) != 0;
        let sbit = op & (1 << 22) != 0;
        let w = op & (1 << 21) != 0;
        let l = op & (1 << 20) != 0;
        let rn = ((op >> 16) & 15) as usize;
        let mut list = op & 0xFFFF;
        let empty = list == 0;
        let n = if empty { 16 } else { list.count_ones() };
        let base = self.r[rn];
        let low = match (u, p) {
            (true, false) => base,
            (true, true) => base.wrapping_add(4),
            (false, false) => base.wrapping_sub(4 * n).wrapping_add(4),
            (false, true) => base.wrapping_sub(4 * n),
        };
        let wb = if u { base.wrapping_add(4 * n) } else { base.wrapping_sub(4 * n) };
        if empty { list = 1 << 15; }
        let user = sbit && !(l && list & (1 << 15) != 0);
        let mut addr = low;
        let mut seq = false;
        let mut first = true;
        if l {
            if list & (1 << 15) != 0 { self.waste(b); }
            if w { self.r[rn] = wb; }
            let mut pc_val = None;
            for i in 0..16usize {
                if list & (1 << i) == 0 { continue; }
                let v = b.read32(addr, seq);
                if i == 15 { pc_val = Some(v); }
                else if user { self.set_user_reg(i, v) } else { self.r[i] = v }
                addr = addr.wrapping_add(4);
                seq = true;
            }
            b.idle(1);
            if let Some(v) = pc_val {
                if sbit { self.restore_spsr(); }
                self.set_pc(b, v);
            }
        } else {
            for i in 0..16usize {
                if list & (1 << i) == 0 { continue; }
                let mut v = if user { self.user_reg(i) } else { self.r[i] };
                if i == rn && w && !first { v = wb; }
                if i == 15 { v = v.wrapping_add(4); }
                b.write32(addr, v, seq);
                if first && w { self.r[rn] = wb; }
                first = false;
                addr = addr.wrapping_add(4);
                seq = true;
            }
        }
    }

    // ---------------------------------------------------------------- THUMB
    fn thumb_undef<B: CpuBus>(&mut self, b: &mut B) {
        let lr = self.r[15].wrapping_sub(2);
        self.exception(b, M_UND, 0x04, lr);
    }

    fn exec_thumb<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        match op >> 11 {
            0..=2 => {
                // shift by immediate
                let rd = (op & 7) as usize;
                let v = self.r[((op >> 3) & 7) as usize];
                let c = self.cpsr & C != 0;
                let (r, c) = shift_imm(op >> 11, v, (op >> 6) & 31, c);
                self.r[rd] = r;
                self.set_nz(r);
                self.set_c(c);
            }
            3 => {
                let rd = (op & 7) as usize;
                let a = self.r[((op >> 3) & 7) as usize];
                let x = if op & (1 << 10) != 0 { (op >> 6) & 7 } else { self.r[((op >> 6) & 7) as usize] };
                self.r[rd] = if op & (1 << 9) != 0 { self.adc(a, !x, 1, true) } else { self.adc(a, x, 0, true) };
            }
            4..=7 => {
                let rd = ((op >> 8) & 7) as usize;
                let imm = op & 0xFF;
                let a = self.r[rd];
                match (op >> 11) & 3 {
                    0 => {
                        self.r[rd] = imm;
                        self.set_nz(imm);
                    }
                    1 => { self.adc(a, !imm, 1, true); }
                    2 => self.r[rd] = self.adc(a, imm, 0, true),
                    _ => self.r[rd] = self.adc(a, !imm, 1, true),
                }
            }
            8 => {
                if op & 0x0400 == 0 { self.thumb_alu(b, op) } else { self.thumb_hi(b, op) }
            }
            9 => {
                // LDR pc-relative
                let rd = ((op >> 8) & 7) as usize;
                let a = (self.r[15] & !3).wrapping_add((op & 0xFF) << 2);
                self.r[rd] = self.ld32(b, a, false);
                b.idle(1);
            }
            10 | 11 => {
                let rm = self.r[((op >> 6) & 7) as usize];
                let a = self.r[((op >> 3) & 7) as usize].wrapping_add(rm);
                let rd = (op & 7) as usize;
                match (op >> 9) & 7 {
                    0 => b.write32(a, self.r[rd], false),
                    1 => b.write16(a, self.r[rd] & 0xFFFF, false),
                    2 => b.write8(a, self.r[rd] & 0xFF, false),
                    3 => { self.r[rd] = self.ld8s(b, a, false); b.idle(1); }
                    4 => { self.r[rd] = self.ld32(b, a, false); b.idle(1); }
                    5 => { self.r[rd] = self.ld16(b, a, false); b.idle(1); }
                    6 => { self.r[rd] = b.read8(a, false) & 0xFF; b.idle(1); }
                    _ => { self.r[rd] = self.ld16s(b, a, false); b.idle(1); }
                }
            }
            12..=15 => {
                let rb = self.r[((op >> 3) & 7) as usize];
                let rd = (op & 7) as usize;
                let imm = (op >> 6) & 31;
                match (op >> 11) & 3 {
                    0 => b.write32(rb.wrapping_add(imm << 2), self.r[rd], false),
                    1 => { let a = rb.wrapping_add(imm << 2); self.r[rd] = self.ld32(b, a, false); b.idle(1); }
                    2 => b.write8(rb.wrapping_add(imm), self.r[rd] & 0xFF, false),
                    _ => { self.r[rd] = b.read8(rb.wrapping_add(imm), false) & 0xFF; b.idle(1); }
                }
            }
            16 | 17 => {
                let rb = self.r[((op >> 3) & 7) as usize];
                let rd = (op & 7) as usize;
                let a = rb.wrapping_add(((op >> 6) & 31) << 1);
                if op & 0x0800 == 0 {
                    b.write16(a, self.r[rd] & 0xFFFF, false);
                } else {
                    self.r[rd] = self.ld16(b, a, false);
                    b.idle(1);
                }
            }
            18 | 19 => {
                let rd = ((op >> 8) & 7) as usize;
                let a = self.r[13].wrapping_add((op & 0xFF) << 2);
                if op & 0x0800 == 0 {
                    b.write32(a, self.r[rd], false);
                } else {
                    self.r[rd] = self.ld32(b, a, false);
                    b.idle(1);
                }
            }
            20 | 21 => {
                let rd = ((op >> 8) & 7) as usize;
                let base = if op & 0x0800 == 0 { self.r[15] & !3 } else { self.r[13] };
                self.r[rd] = base.wrapping_add((op & 0xFF) << 2);
            }
            22 | 23 => {
                if op & 0x0F00 == 0 {
                    let off = (op & 0x7F) << 2;
                    self.r[13] = if op & 0x80 != 0 { self.r[13].wrapping_sub(off) } else { self.r[13].wrapping_add(off) };
                } else if op & 0x0600 == 0x0400 {
                    self.thumb_pushpop(b, op);
                } else {
                    self.thumb_undef(b);
                }
            }
            24 | 25 => self.thumb_block(b, op),
            26 | 27 => {
                let c = (op >> 8) & 15;
                if c == 15 {
                    let lr = self.r[15].wrapping_sub(2);
                    self.exception(b, M_SVC, 0x08, lr);
                } else if c == 14 {
                    self.thumb_undef(b);
                } else if self.cond_ok(c) {
                    let off = (((op & 0xFF) << 24) as i32 >> 23) as u32;
                    let t = self.r[15].wrapping_add(off);
                    self.set_pc(b, t);
                }
            }
            28 => {
                let off = (((op & 0x7FF) << 21) as i32 >> 20) as u32;
                let t = self.r[15].wrapping_add(off);
                self.set_pc(b, t);
            }
            29 => self.thumb_undef(b),
            30 => {
                let off = (((op & 0x7FF) << 21) as i32 >> 9) as u32;
                self.r[14] = self.r[15].wrapping_add(off);
            }
            _ => {
                let t = self.r[14].wrapping_add((op & 0x7FF) << 1);
                self.r[14] = self.r[15].wrapping_sub(2) | 1;
                self.set_pc(b, t);
            }
        }
    }

    fn thumb_alu<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let rd = (op & 7) as usize;
        let rs = self.r[((op >> 3) & 7) as usize];
        let a = self.r[rd];
        let cf = self.cpsr & C != 0;
        let cin = cf as u32;
        let logic = |s: &mut Self, r: u32| { s.r[rd] = r; s.set_nz(r); };
        match (op >> 6) & 15 {
            0 => logic(self, a & rs),
            1 => logic(self, a ^ rs),
            2 | 3 | 4 | 7 => {
                b.idle(1);
                let typ = match (op >> 6) & 15 { 2 => 0, 3 => 1, 4 => 2, _ => 3 };
                let (r, c) = shift_reg(typ, a, rs & 0xFF, cf);
                self.r[rd] = r;
                self.set_nz(r);
                self.set_c(c);
            }
            5 => self.r[rd] = self.adc(a, rs, cin, true),
            6 => self.r[rd] = self.adc(a, !rs, cin, true),
            8 => self.set_nz(a & rs),
            9 => self.r[rd] = self.adc(0, !rs, 1, true),
            10 => { self.adc(a, !rs, 1, true); }
            11 => { self.adc(a, rs, 0, true); }
            12 => logic(self, a | rs),
            13 => {
                b.idle(mul_cycles(a, true));
                logic(self, a.wrapping_mul(rs));
            }
            14 => logic(self, a & !rs),
            _ => logic(self, !rs),
        }
    }

    fn thumb_hi<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let rd = ((op & 7) | ((op >> 4) & 8)) as usize;
        let rs = ((op >> 3) & 15) as usize;
        let s = self.r[rs];
        let d = self.r[rd];
        match (op >> 8) & 3 {
            0 => {
                let v = d.wrapping_add(s);
                if rd == 15 { self.set_pc(b, v) } else { self.r[rd] = v }
            }
            1 => { self.adc(d, !s, 1, true); }
            2 => {
                if rd == 15 { self.set_pc(b, s) } else { self.r[rd] = s }
            }
            _ => {
                if s & 1 == 0 { self.cpsr &= !FT; }
                self.set_pc(b, s);
            }
        }
    }

    fn thumb_pushpop<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let list = op & 0xFF;
        let extra = op & 0x100 != 0;
        let n = list.count_ones() + extra as u32;
        let mut seq = false;
        if op & 0x0800 == 0 {
            // PUSH
            let mut a = self.r[13].wrapping_sub(4 * n);
            self.r[13] = a;
            for i in 0..8 {
                if list & (1 << i) != 0 {
                    b.write32(a, self.r[i], seq);
                    a = a.wrapping_add(4);
                    seq = true;
                }
            }
            if extra {
                b.write32(a, self.r[14], seq);
            }
        } else {
            let mut a = self.r[13];
            if extra { self.waste(b); }
            for i in 0..8 {
                if list & (1 << i) != 0 {
                    self.r[i] = b.read32(a, seq);
                    a = a.wrapping_add(4);
                    seq = true;
                }
            }
            if extra {
                let v = b.read32(a, seq);
                a = a.wrapping_add(4);
                self.r[13] = a;
                b.idle(1);
                self.set_pc(b, v);
                return;
            }
            self.r[13] = a;
            b.idle(1);
        }
    }

    fn thumb_block<B: CpuBus>(&mut self, b: &mut B, op: u32) {
        let rn = ((op >> 8) & 7) as usize;
        let l = op & 0x0800 != 0;
        let mut list = op & 0xFF;
        let empty = list == 0;
        let n = if empty { 16 } else { list.count_ones() };
        if empty { list = 1 << 15; }
        let base = self.r[rn];
        let wb = base.wrapping_add(4 * n);
        let mut a = base;
        let mut seq = false;
        if l {
            let mut pc_val = None;
            if list & (1 << 15) != 0 { self.waste(b); }
            for i in 0..16usize {
                if list & (1 << i) == 0 { continue; }
                let v = b.read32(a, seq);
                if i == 15 { pc_val = Some(v) } else { self.r[i] = v }
                a = a.wrapping_add(4);
                seq = true;
            }
            b.idle(1);
            if list & (1 << rn) == 0 { self.r[rn] = wb; }
            if let Some(v) = pc_val { self.set_pc(b, v); }
        } else {
            let mut first = true;
            for i in 0..16usize {
                if list & (1 << i) == 0 { continue; }
                let mut v = self.r[i];
                if i == rn && !first { v = wb; }
                if i == 15 { v = v.wrapping_add(2); }
                b.write32(a, v, seq);
                if first { self.r[rn] = wb; }
                first = false;
                a = a.wrapping_add(4);
                seq = true;
            }
        }
    }
}

#[allow(dead_code)]
const _UNUSED: u32 = M_ABT;

#[cfg(test)]
mod tests {
    use super::*;
    struct M { m: Vec<u8>, cyc: u32 }
    impl CpuBus for M {
        fn read8(&mut self, a: u32, _: bool) -> u32 { self.cyc += 1; self.m[a as usize] as u32 }
        fn read16(&mut self, a: u32, _: bool) -> u32 { self.cyc += 1; let a = (a & !1) as usize; u16::from_le_bytes([self.m[a], self.m[a + 1]]) as u32 }
        fn read32(&mut self, a: u32, _: bool) -> u32 { self.cyc += 1; let a = (a & !3) as usize; u32::from_le_bytes(self.m[a..a + 4].try_into().unwrap()) }
        fn write8(&mut self, a: u32, v: u32, _: bool) { self.m[a as usize] = v as u8 }
        fn write16(&mut self, a: u32, v: u32, _: bool) { let a = (a & !1) as usize; self.m[a..a + 2].copy_from_slice(&(v as u16).to_le_bytes()) }
        fn write32(&mut self, a: u32, v: u32, _: bool) { let a = (a & !3) as usize; self.m[a..a + 4].copy_from_slice(&v.to_le_bytes()) }
        fn idle(&mut self, c: u32) { self.cyc += c }
        fn irq_line(&self) -> bool { false }
        fn halted(&self) -> bool { false }
    }
    fn run(code: &[u32], n: usize) -> Cpu {
        let mut m = M { m: vec![0; 0x10000], cyc: 0 };
        for (i, w) in code.iter().enumerate() { m.m[i * 4..i * 4 + 4].copy_from_slice(&w.to_le_bytes()); }
        let mut c = Cpu::new();
        c.cpsr = 0x1F;
        for _ in 0..n { c.step_g(&mut m); }
        c
    }
    #[test]
    fn arm_basic() {
        // mov r0,#5 ; adds r1,r0,#-? ; subs r2,r0,r0 ; ldr via pc; bl
        let c = run(&[0xE3A00005, 0xE0901000, 0xE0502000 , 0xE1A03F10 /*lsl r3,r0,pc? */], 3);
        assert_eq!(c.r[0], 5);
        assert_eq!(c.r[1], 10);
        assert_eq!(c.r[2], 0);
        assert!(c.cpsr & (Z | C) == Z | C);
    }
    #[test]
    fn thumb_and_bx() {
        // add r0,pc,#1 ; bx r0 (thumb at 8) ; thumb: mov r1,#7 ; mov r2,#9
        let c = run(&[0xE28F0001, 0xE12FFF10, 0x2209_2107], 4);
        assert!(c.cpsr & FT != 0);
        assert_eq!((c.r[1], c.r[2]), (7, 9));
    }
    #[test]
    fn mode_banks() {
        // mov r13,#1; msr cpsr,#0xD2 (irq); mov r13,#2; msr cpsr,#0x1F; 
        let c = run(&[0xE3A0D001, 0xE321F0D2, 0xE3A0D002, 0xE321F01F], 4);
        assert_eq!(c.r[13], 1);
        assert_eq!(c.bank_sp[2], 2);
    }

    #[test]
    #[ignore]
    fn bench_core() {
        // loop: add r0,r0,r1 ; eor r2,r2,r0 ; ldr r3,[r4] ; str r3,[r4,#4] ; subs r5,r5,#1 ; bne loop
        let code = [0xE0800001u32, 0xE0222000, 0xE5943000, 0xE5843004, 0xE2555001, 0x1AFFFFFA];
        let mut m = M { m: vec![0; 0x10000], cyc: 0 };
        for (i, w) in code.iter().enumerate() { m.m[i * 4..i * 4 + 4].copy_from_slice(&w.to_le_bytes()); }
        let mut c = Cpu::new();
        c.cpsr = 0x1F;
        c.r[4] = 0x8000;
        c.r[5] = u32::MAX;
        let t = std::time::Instant::now();
        for _ in 0..60_000_000 { c.step_g(&mut m); }
        eprintln!("60M steps: {:?} cyc={}", t.elapsed(), m.cyc);
    }
    /// ROM runner: ROM=path FRAMES=n OUT=file.ppm cargo test --release run_rom -- --ignored --nocapture
    #[test]
    #[ignore]
    fn run_rom() {
        let data = std::fs::read(std::env::var("ROM").unwrap()).unwrap();
        let frames: u64 = std::env::var("FRAMES").map(|v| v.parse().unwrap()).unwrap_or(60);
        let mut bus = Bus::new();
        bus.rom[..data.len()].copy_from_slice(&data);
        bus.rom_len = data.len();
        bus.reset();
        let mut cpu = Cpu::new();
        bus.ppu.write_io(0x20, 0x100, 0xFFFF); bus.ppu.write_io(0x26, 0x100, 0xFFFF);
        let mut n = 0u32;
        let nosync = std::env::var("NOSYNC").is_ok();
        let mut seen_rom = false;
        let mut tr2: i64 = std::env::var("TRACE2").map(|v| v.parse().unwrap()).unwrap_or(0);
        // KEYSEQ="frame:mask,frame:mask" (mask active-high, hex)
        let mut ks = std::env::var("KEYSEQ").unwrap_or_default();
        if let Ok(rp) = std::env::var("REPLAY") {
            ks = std::fs::read_to_string(rp).unwrap().lines().filter(|l| !l.starts_with('#') && !l.trim().is_empty())
                .map(|l| { let mut it = l.split_whitespace(); format!("{}:{}", it.next().unwrap(), it.next().unwrap()) }).collect::<Vec<_>>().join(",");
        }
        let seq: Vec<(u64, u32)> = ks.split(',').filter(|x| !x.is_empty())
            .map(|x| { let (f, m) = x.split_once(':').unwrap(); (f.parse().unwrap(), u32::from_str_radix(m, 16).unwrap()) }).collect();
        let mut si = 0;
        while bus.cycles < frames * 280896 {
            while si < seq.len() && bus.cycles >= seq[si].0 * 280896 { bus.set_keys(seq[si].1); si += 1; }
            if std::env::var("TRACE").is_ok() && n < 6000000 { n += 1; eprintln!("{:08x} {:08x} cpsr={:08x} r0={:x} r1={:x} r2={:x} sp={:x} lr={:x}", cpu.r[15].wrapping_sub(if cpu.cpsr & FT != 0 {4} else {8}), cpu.pipe[0], cpu.cpsr, cpu.r[0], cpu.r[1], cpu.r[2], cpu.r[13], cpu.r[14]); }
            let (c0, p0) = (bus.cycles, cpu.r[15]);
            cpu.step(&mut bus);
            if tr2 > 0 && p0 >= 0x0800_0000 { if !seen_rom { seen_rom = true; eprintln!("rom entry cycles {}", c0); } tr2 -= 1; eprintln!("T {:08x} {}", p0, bus.cycles - c0); }
            if !nosync || bus.cycles % 1024 < 8 { bus.sync(); }
        }
        let mut out = b"P6\n240 160\n255\n".to_vec();
        for p in &bus.ppu.fb { out.extend_from_slice(&[*p as u8, (*p >> 8) as u8, (*p >> 16) as u8]); }
        std::fs::write(std::env::var("OUT").unwrap(), out).unwrap();
        eprintln!("io={:04x?}", (0x08..0x30).step_by(2).map(|o| bus.ppu.read_io(o)).collect::<Vec<_>>());
        eprintln!("pal={:02x?} dispcnt={:04x} nz={} pal={:02x?}", &bus.ppu.pal[..8], bus.ppu.read_io(0), bus.ppu.vram.iter().filter(|x| **x!=0).count(), &bus.ppu.pal[..16]);
        eprintln!("pc={:08x} cpsr={:08x} cycles={}", cpu.r[15], cpu.cpsr, bus.cycles);
    }
}
