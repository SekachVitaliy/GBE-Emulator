#!/usr/bin/env bash
# Usage: scripts/grade.sh [wasm]   (default: target/.../gba_emu.wasm)
# Writes gba-emu/results/<timestamp>/ and appends a line to scores.md.
set -euo pipefail
. "$(dirname "$0")/env.sh"
WASM=$(cd "$(dirname "${1:-$WASM_DEFAULT}")" && pwd)/$(basename "${1:-$WASM_DEFAULT}")
[ -f "$WASM" ] || { echo "no wasm: $WASM" >&2; exit 1; }
[ -x "$GRADER" ] || { echo "grader not built: run scripts/precompute.sh" >&2; exit 1; }
if head -c 40 "$EVAL/corpus/reference-cache/aw-arm-alu.refcache" | grep -q '^version https://git-lfs'; then
  echo "refcache is LFS pointers: run scripts/precompute.sh" >&2; exit 1; fi
TS=$(date +%Y%m%dT%H%M%S)
OUT=$EMU/results/$TS
mkdir -p "$OUT"
cd "$EVAL"
"$GRADER" --reference "$EVAL/reference/mesen.wasm" "$WASM" corpus/ "$OUT" 2>&1 | tee "$OUT/grader.log" | tail -5 || true
[ -f "$OUT/summary.json" ] || { echo "no summary.json, see $OUT/grader.log" >&2; exit 1; }
mkdir -p "$(dirname "$SCORES")"
python3 "$EMU/scripts/worst.py" "$OUT" --line "$(basename "$WASM")" >> "$SCORES"
python3 "$EMU/scripts/worst.py" "$OUT"
echo "results: $OUT"
# disk is tight: each run's PNGs are ~230MB; keep PNGs only for the 2 newest runs
for d in $(ls -1dr "$EMU"/results/*/ | tail -n +3); do rm -f "${d:?}"*.png; done
